import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, MapPin, Phone, Mail, Send, CheckCircle } from "lucide-react";
import { useState, type FormEvent } from "react";
import emailjs from "@emailjs/browser";

export const Route = createFileRoute("/hire-me")({
	component: HireMePage,
});

const serviceOptions = [
	"Music Promotion",
	"YouTube Growth",
	"Playlist Pitching",
	"Spotify Promotion",
	"Social Media Management",
	"Brand Identity Design",
	"Visual Content Creation",
	"Marketing Strategy",
	"Campaign Management",
	"Other",
];

const budgetOptions = [
	"Less than $100",
	"$100 - $250",
	"$250 - $500",
	"$500 - $1000",
	"More than $1000",
];

function HireMePage() {
	const [formData, setFormData] = useState({
		firstName: "",
		lastName: "",
		email: "",
		phone: "",
		service: "",
		budget: "",
		message: "",
	});
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [isSubmitted, setIsSubmitted] = useState(false);
	const [error, setError] = useState("");

	const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
		const { name, value } = e.target;
		setFormData((prev) => ({ ...prev, [name]: value }));
	};

	const handleSubmit = async (e: FormEvent) => {
		e.preventDefault();
		setIsSubmitting(true);
		setError("");

		// Validate required fields
		if (!formData.firstName || !formData.lastName || !formData.email || !formData.service || !formData.budget || !formData.message) {
			setError("Please fill in all required fields.");
			setIsSubmitting(false);
			return;
		}

		// Email validation
		const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		if (!emailRegex.test(formData.email)) {
			setError("Please enter a valid email address.");
			setIsSubmitting(false);
			return;
		}

		try {
			await emailjs.send(
				"service_troy",
				"template_hire",
				{
					from_name: `${formData.firstName} ${formData.lastName}`,
					from_email: formData.email,
					phone: formData.phone || "Not provided",
					message: formData.message,
					to_name: "Troy Digital Desk",
				},
				"YOUR_PUBLIC_KEY"
			);

			setIsSubmitted(true);
			setFormData({
				firstName: "",
				lastName: "",
				email: "",
				phone: "",
				service: "",
				budget: "",
				message: "",
			});
		} catch {
			// Fallback: Open WhatsApp with the message
			const whatsappMessage = encodeURIComponent(
				`Hi! I'm ${formData.firstName} ${formData.lastName}.\n\nEmail: ${formData.email}\nPhone: ${formData.phone || "Not provided"}\nService: ${formData.service}\nBudget: ${formData.budget}\n\nMessage: ${formData.message}`
			);
			window.open(`https://wa.me/256701705378?text=${whatsappMessage}`, "_blank");
			setIsSubmitted(true);
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<div className="min-h-screen bg-zinc-950 text-white relative overflow-hidden">
			{/* Background */}
			<div className="absolute inset-0 bg-gradient-to-br from-zinc-900 via-zinc-950 to-black" />
			<div
				className="absolute inset-0 opacity-20"
				style={{
					backgroundImage: `
						linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
						linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)
					`,
					backgroundSize: "60px 60px",
				}}
			/>

			{/* Gradient Orbs */}
			<div className="absolute top-20 left-10 w-72 h-72 bg-[#BFFF00]/10 rounded-full blur-3xl" />
			<div className="absolute bottom-20 right-10 w-96 h-96 bg-[#BFFF00]/5 rounded-full blur-3xl" />

			{/* Header */}
			<header className="relative z-10 py-4 sm:py-6 px-4 sm:px-6">
				<div className="max-w-6xl mx-auto flex items-center justify-between">
					<Link
						to="/"
						className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors"
					>
						<ChevronLeft className="size-5" />
						<span className="text-sm font-medium">Back to Home</span>
					</Link>
					<img
						src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
						alt="Troy Digital Desk"
						className="h-6 sm:h-8 w-auto"
					/>
				</div>
			</header>

			{/* Main Content */}
			<main className="relative z-10 py-8 sm:py-12 lg:py-16 px-4 sm:px-6">
				<div className="max-w-6xl mx-auto">
					{/* Page Title */}
					<div className="text-center mb-10 sm:mb-14">
						<h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
							Let's Work <span className="text-[#BFFF00]">Together</span>
						</h1>
						<p className="text-zinc-400 text-sm sm:text-base max-w-xl mx-auto">
							Ready to take your music career to the next level? Fill out the form below and let's discuss how we can help you grow.
						</p>
					</div>

					{/* Form Container */}
					<div className="bg-zinc-900/50 backdrop-blur-sm border border-zinc-800 rounded-2xl sm:rounded-3xl overflow-hidden">
						<div className="grid lg:grid-cols-5">
							{/* Left: Contact Form */}
							<div className="lg:col-span-3 p-6 sm:p-8 lg:p-10">
								<h2 className="text-xl sm:text-2xl font-bold mb-6">Send a Message</h2>

								{isSubmitted ? (
									<div className="flex flex-col items-center justify-center py-12 text-center">
										<div className="size-16 bg-[#BFFF00]/20 rounded-full flex items-center justify-center mb-4">
											<CheckCircle className="size-8 text-[#BFFF00]" />
										</div>
										<h3 className="text-xl font-semibold mb-2">Message Sent!</h3>
										<p className="text-zinc-400 text-sm mb-6">
											Thank you for reaching out. We'll get back to you within 24 hours.
										</p>
										<button
											onClick={() => setIsSubmitted(false)}
											className="text-[#BFFF00] hover:underline text-sm"
										>
											Send another message
										</button>
									</div>
								) : (
									<form onSubmit={handleSubmit} className="space-y-5">
										{/* Name Row */}
										<div className="grid sm:grid-cols-2 gap-4">
											<div>
												<label htmlFor="firstName" className="block text-sm text-zinc-400 mb-2">
													First Name <span className="text-red-500">*</span>
												</label>
												<input
													type="text"
													id="firstName"
													name="firstName"
													value={formData.firstName}
													onChange={handleChange}
													placeholder="John"
													className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white placeholder:text-zinc-500 focus:outline-none focus:border-[#BFFF00] focus:ring-1 focus:ring-[#BFFF00]/50 transition-all"
												/>
											</div>
											<div>
												<label htmlFor="lastName" className="block text-sm text-zinc-400 mb-2">
													Last Name <span className="text-red-500">*</span>
												</label>
												<input
													type="text"
													id="lastName"
													name="lastName"
													value={formData.lastName}
													onChange={handleChange}
													placeholder="Doe"
													className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white placeholder:text-zinc-500 focus:outline-none focus:border-[#BFFF00] focus:ring-1 focus:ring-[#BFFF00]/50 transition-all"
												/>
											</div>
										</div>

										{/* Email */}
										<div>
											<label htmlFor="email" className="block text-sm text-zinc-400 mb-2">
												Email Address <span className="text-red-500">*</span>
											</label>
											<input
												type="email"
												id="email"
												name="email"
												value={formData.email}
												onChange={handleChange}
												placeholder="john@example.com"
												className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white placeholder:text-zinc-500 focus:outline-none focus:border-[#BFFF00] focus:ring-1 focus:ring-[#BFFF00]/50 transition-all"
											/>
										</div>

										{/* Phone */}
										<div>
											<label htmlFor="phone" className="block text-sm text-zinc-400 mb-2">
												Phone Number
											</label>
											<input
												type="tel"
												id="phone"
												name="phone"
												value={formData.phone}
												onChange={handleChange}
												placeholder="+256 700 000 000"
												className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white placeholder:text-zinc-500 focus:outline-none focus:border-[#BFFF00] focus:ring-1 focus:ring-[#BFFF00]/50 transition-all"
											/>
										</div>

										{/* Service & Budget Row */}
										<div className="grid sm:grid-cols-2 gap-4">
											{/* Required Service */}
											<div>
												<label htmlFor="service" className="block text-sm text-zinc-400 mb-2">
													Required Service <span className="text-red-500">*</span>
												</label>
												<select
													id="service"
													name="service"
													value={formData.service}
													onChange={handleChange}
													className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-[#BFFF00] focus:ring-1 focus:ring-[#BFFF00]/50 transition-all appearance-none cursor-pointer"
												>
													<option value="" className="bg-zinc-800">Select a service...</option>
													{serviceOptions.map((service) => (
														<option key={service} value={service} className="bg-zinc-800">
															{service}
														</option>
													))}
												</select>
											</div>

											{/* Projected Budget */}
											<div>
												<label htmlFor="budget" className="block text-sm text-zinc-400 mb-2">
													Projected Budget <span className="text-red-500">*</span>
												</label>
												<select
													id="budget"
													name="budget"
													value={formData.budget}
													onChange={handleChange}
													className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white focus:outline-none focus:border-[#BFFF00] focus:ring-1 focus:ring-[#BFFF00]/50 transition-all appearance-none cursor-pointer"
												>
													<option value="" className="bg-zinc-800">Select budget...</option>
													{budgetOptions.map((budget) => (
														<option key={budget} value={budget} className="bg-zinc-800">
															{budget}
														</option>
													))}
												</select>
											</div>
										</div>

										{/* Message */}
										<div>
											<label htmlFor="message" className="block text-sm text-zinc-400 mb-2">
												Your Message <span className="text-red-500">*</span>
											</label>
											<textarea
												id="message"
												name="message"
												value={formData.message}
												onChange={handleChange}
												placeholder="Tell us about your project, goals, and how we can help..."
												rows={5}
												className="w-full px-4 py-3 bg-zinc-800/50 border border-zinc-700 rounded-xl text-white placeholder:text-zinc-500 focus:outline-none focus:border-[#BFFF00] focus:ring-1 focus:ring-[#BFFF00]/50 transition-all resize-none"
											/>
										</div>

										{/* Error Message */}
										{error && (
											<div className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3">
												{error}
											</div>
										)}

										{/* Submit Button */}
										<button
											type="submit"
											disabled={isSubmitting}
											className="w-full flex items-center justify-center gap-2 bg-[#BFFF00] hover:bg-[#a8e600] disabled:bg-zinc-700 text-zinc-900 disabled:text-zinc-400 font-semibold py-4 rounded-xl transition-all hover:scale-[1.02] disabled:hover:scale-100"
										>
											{isSubmitting ? (
												<>
													<div className="size-5 border-2 border-zinc-900/30 border-t-zinc-900 rounded-full animate-spin" />
													Sending...
												</>
											) : (
												<>
													<Send className="size-5" />
													Send Message
												</>
											)}
										</button>
									</form>
								)}
							</div>

							{/* Right: Contact Info */}
							<div className="lg:col-span-2 bg-gradient-to-br from-[#BFFF00] to-[#8bc700] p-6 sm:p-8 lg:p-10 text-zinc-900">
								<h2 className="text-xl sm:text-2xl font-bold mb-6">Contact Information</h2>
								<p className="text-zinc-800 text-sm mb-8">
									Prefer to reach out directly? Here's how you can get in touch with us.
								</p>

								<div className="space-y-6">
									{/* Office Address */}
									<div className="flex items-start gap-4">
										<div className="size-12 bg-zinc-900/10 rounded-xl flex items-center justify-center flex-shrink-0">
											<MapPin className="size-6 text-zinc-900" />
										</div>
										<div>
											<h3 className="font-semibold mb-1">Office Address</h3>
											<p className="text-zinc-800 text-sm">
												Makindye - Luwafu,<br />
												Kampala UG
											</p>
										</div>
									</div>

									{/* Phone */}
									<div className="flex items-start gap-4">
										<div className="size-12 bg-zinc-900/10 rounded-xl flex items-center justify-center flex-shrink-0">
											<Phone className="size-6 text-zinc-900" />
										</div>
										<div>
											<h3 className="font-semibold mb-1">Call Us</h3>
											<a
												href="tel:+256701705378"
												className="text-zinc-800 text-sm hover:text-zinc-900 transition-colors"
											>
												+256 701 705 378
											</a>
										</div>
									</div>

									{/* Email */}
									<div className="flex items-start gap-4">
										<div className="size-12 bg-zinc-900/10 rounded-xl flex items-center justify-center flex-shrink-0">
											<Mail className="size-6 text-zinc-900" />
										</div>
										<div>
											<h3 className="font-semibold mb-1">Email Us</h3>
											<a
												href="mailto:music@troydigitaldesk.com"
												className="text-zinc-800 text-sm hover:text-zinc-900 transition-colors"
											>
												music@troydigitaldesk.com
											</a>
										</div>
									</div>
								</div>

								{/* Social Links */}
								<div className="mt-10 pt-8 border-t border-zinc-900/20">
									<h3 className="font-semibold mb-4">Follow Us</h3>
									<div className="flex gap-3">
										{/* WhatsApp */}
										<a
											href="https://wa.me/256701705378"
											target="_blank"
											rel="noopener noreferrer"
											className="size-10 bg-zinc-900/10 hover:bg-zinc-900/20 rounded-lg flex items-center justify-center transition-colors"
										>
											<svg className="size-5 text-zinc-900" viewBox="0 0 24 24" fill="currentColor">
												<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
											</svg>
										</a>
										{/* Instagram */}
										<a
											href="https://instagram.com/troydigitaldesk"
											target="_blank"
											rel="noopener noreferrer"
											className="size-10 bg-zinc-900/10 hover:bg-zinc-900/20 rounded-lg flex items-center justify-center transition-colors"
										>
											<svg className="size-5 text-zinc-900" viewBox="0 0 24 24" fill="currentColor">
												<path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
											</svg>
										</a>
										{/* YouTube */}
										<a
											href="https://youtube.com/@troydigitaldesk"
											target="_blank"
											rel="noopener noreferrer"
											className="size-10 bg-zinc-900/10 hover:bg-zinc-900/20 rounded-lg flex items-center justify-center transition-colors"
										>
											<svg className="size-5 text-zinc-900" viewBox="0 0 24 24" fill="currentColor">
												<path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
											</svg>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</main>

			{/* Footer */}
			<footer className="relative z-10 border-t border-zinc-800 mt-12 px-4 sm:px-6 py-6">
				<div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
					<p className="text-zinc-500 text-xs sm:text-sm">
						© 2025 Troy Digital Desk. All rights reserved.
					</p>
					<Link to="/" className="text-zinc-400 hover:text-white text-xs sm:text-sm transition-colors">
						Back to Home
					</Link>
				</div>
			</footer>
		</div>
	);
}

export default HireMePage;
